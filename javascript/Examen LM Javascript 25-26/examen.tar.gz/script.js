// CE.c

let btnadd = document.getElementById(btnAdd);
let btnborrar = document.getElementById(btnDelete);
let textos = document.getElementById(texto);
let btnoscuro = document.getElementById(btnDark);
let listas = document.getElementById(lista);
let titulo = document.getElementById(titulo);




// CE.d
addEventListener(array.forEach(Element => {}));
addEventListener(array.forEach(Element => {}));






if (textos==""){
    alert("No se puede dejar el texto en blanco")
}




// CE.e










// CE.f


