// ==========================
// CE.c — Selección DOM
// ==========================






// ==========================
// CE.d — Crear y modificar
// ==========================



  // CE.b — condicional
 

  // Crear elemento
  

  // Modificar contenido
  

  // Evento seleccionar + editar
  

  // Insertar en DOM
  

  // limpieza input



// ==========================
// CE.e — Eliminar
// ==========================






// ==========================
// CE.f — Estilos dinámicos
// ==========================




